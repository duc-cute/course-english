---
name: Course English Design System
colors:
  surface: '#faf9ff'
  surface-dim: '#ccdaff'
  surface-bright: '#faf9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f1f3ff'
  surface-container: '#e9edff'
  surface-container-high: '#e1e8ff'
  surface-container-highest: '#d8e2ff'
  on-surface: '#051a3e'
  on-surface-variant: '#434654'
  inverse-surface: '#1d3054'
  inverse-on-surface: '#edf0ff'
  outline: '#737685'
  outline-variant: '#c3c6d6'
  surface-tint: '#0c56d0'
  primary: '#003d9b'
  on-primary: '#ffffff'
  primary-container: '#0052cc'
  on-primary-container: '#c4d2ff'
  inverse-primary: '#b2c5ff'
  secondary: '#006c47'
  on-secondary: '#ffffff'
  secondary-container: '#82f9be'
  on-secondary-container: '#00734c'
  tertiary: '#5e3c00'
  on-tertiary: '#ffffff'
  tertiary-container: '#7d5200'
  on-tertiary-container: '#ffca81'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dae2ff'
  primary-fixed-dim: '#b2c5ff'
  on-primary-fixed: '#001848'
  on-primary-fixed-variant: '#0040a2'
  secondary-fixed: '#82f9be'
  secondary-fixed-dim: '#65dca4'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005235'
  tertiary-fixed: '#ffddb3'
  tertiary-fixed-dim: '#ffb950'
  on-tertiary-fixed: '#291800'
  on-tertiary-fixed-variant: '#624000'
  background: '#faf9ff'
  on-background: '#051a3e'
  surface-variant: '#d8e2ff'
typography:
  display-lg:
    fontFamily: Public Sans
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Public Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Public Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  headline-lg-mobile:
    fontFamily: Public Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  container-padding-desktop: 32px
  container-padding-mobile: 16px
  gutter: 24px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 24px
---

## Brand & Style
The design system is engineered to bridge the gap between high-performance SaaS utility and the dopamine-driven engagement of modern language learning. It targets a dual audience: educators who require precision and clarity, and students who thrive on progress visualization and friendly interaction.

The visual style is **Corporate / Modern** with a **Tactile** twist. It utilizes "Apple-quality" white space and depth, while borrowing the high-contrast, playful energy of gamified platforms. The aesthetic is clean, trustworthy, and premium, avoiding the "clinical" feel of traditional LMS software in favor of an approachable, energetic interface.

## Colors
The palette is rooted in a "Trustworthy Blue" that anchors the professional SaaS experience. This is balanced by a high-chroma secondary palette designed for behavioral feedback:
- **Primary (Blue):** Used for navigation, primary actions, and branding elements.
- **Success (Vibrant Green):** Dedicated to XP gains, correct answers, and completion states.
- **Achievement (Gold):** Specifically for streaks, rewards, and high-level milestones.
- **Warning (Soft Orange):** Used for low-engagement alerts and student "at-risk" indicators.
- **Neutrals:** A range of cool grays provides structure without competing with the vibrant accent colors. Backgrounds use a very light tint of blue-gray to maintain a "fresh" feel.

## Typography
The system employs a dual-font strategy. **Public Sans** is used for headlines to provide a sturdy, institutional quality that feels modern and authoritative. **Inter** is used for all body text, data tables, and interface labels to ensure maximum legibility at small sizes and high-density information layouts. 

Hierarchy is established through tight leading and slight negative letter-spacing in headlines to create a compact, "premium" feel. For students, larger body sizes (18px) are preferred for reading passages to reduce cognitive load.

## Layout & Spacing
This design system utilizes a **12-column Fluid Grid** for dashboards and a **Fixed Central Column** (800px max-width) for learning content to focus the student's attention.

The spacing rhythm is based on a 4px baseline, with generous margins (32px on desktop) to evoke a "high-end" premium feel. Content cards and layout sections use a consistent 24px gutter. On mobile, margins shrink to 16px, and multi-column dashboard widgets reflow into a single-column vertical stack.

## Elevation & Depth
Depth is created through **Tonal Layers** combined with **Ambient Shadows**. 
1. **Base:** The primary background uses a neutral-light tint.
2. **Surface:** Cards and main content areas use pure white with a 1px border (#DFE1E6).
3. **Elevated:** Elements like active task cards or modals use extra-diffused shadows (Blur: 20px, Y: 8px, Opacity: 6% Primary Color).

This "tinted shadow" technique keeps the UI looking clean and connected to the brand color, avoiding the "dirty" look of pure black shadows.

## Shapes
A "Rounded" shape language is central to the friendly, EdTech personality. 
- **Standard Elements:** Buttons and input fields use a 0.5rem (8px) radius.
- **Containers:** Dashboard cards and learning modules use a 1rem (16px) radius to feel more inviting.
- **Large Components:** Modals and "success" celebrations use 1.5rem (24px) to emphasize the friendly, gamified aspect of the brand.

## Components
- **Buttons:** High-contrast primary buttons use a solid background with a subtle "inner-glow" top border for a tactile feel. Secondary buttons use a ghost-style outline.
- **Gamified Chips:** XP and Streak indicators are styled as "pills" with high-saturation backgrounds and white text, featuring a small icon prefix.
- **Learning Cards:** These use a thick bottom-border (2px) in the secondary color to provide a "pressable" physical appearance, similar to Duolingo.
- **Progress Bars:** Use a thick (12px), rounded track with a vibrant green fill and a subtle stripe pattern for active states.
- **Input Fields:** Large, 48px height fields with 16px internal padding and a 2px blue focus ring to ensure accessibility and clarity.
- **Status Badges:** "At Risk" students are marked with soft orange background badges with dark orange text, using "Public Sans" for the label weight.